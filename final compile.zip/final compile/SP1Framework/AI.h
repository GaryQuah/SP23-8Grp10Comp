#pragma once
#include "game.h"

void MovingAI(struct ROBOTS *BOT, int BotNumber);